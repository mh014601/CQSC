<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=0">

    <title>我的收藏</title>

    <link href="<?php echo e(asset('AmazeUI-2.4.2/assets/css/admin.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('AmazeUI-2.4.2/assets/css/amazeui.css')); ?>" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <link href="<?php echo e(asset('css/personal.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/colstyle.css')); ?>" rel="stylesheet" type="text/css">
    <script src="<?php echo e(asset('layui/layui/layui.js')); ?>"></script>
</head>

<body>
<!--头 -->
<header>
    <article>
        <div class="mt-logo">
            <!--顶部导航条 -->
           <?php echo $__env->make('Public.header1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!--悬浮搜索框-->

            <?php echo $__env->make('Public.seach1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="clear"></div>
        </div>
        </div>
    </article>
</header>
<div class="nav-table">
    <?php echo $__env->make('Public.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<b class="line"></b>
<div class="center">
    <div class="col-main">
        <div class="main-wrap">

            <div class="user-collection">
                <!--标题 -->
                <div class="am-cf am-padding">
                    <div class="am-fl am-cf"><strong class="am-text-danger am-text-lg">我的收藏</strong> / <small>My&nbsp;Collection</small></div>
                    &nbsp;&nbsp;&nbsp;
                    <a href="javascript:void(0)"><del class="am-icon-trash goods-All" ></del></a>
                    <s class="line"></s>
                </div>
                <hr/>
                <div class="you-like">
                    <div class="s-content">

                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="s-item-wrap">
                                <div class="s-item">

                                    <div class="s-pic">
                                        <a href="<?php echo e(url('Goods/info')); ?>?id=<?php echo e($v->id); ?>" class="s-pic-link">
                                            <img src='<?php echo e(asset("upload/$v->pic")); ?>' alt="4折抢购!十二生肖925银女戒指,时尚开口女戒" title="4折抢购!十二生肖925银女戒指,时尚开口女戒" class="s-pic-img s-guess-item-img">
                                            
                                        </a>
                                    </div>

                                    <div class="s-info">
                                        <div class="s-title"><a href="<?php echo e(url('Home/Goods/goodsInfo')); ?>?id=<?php echo e($v->id); ?>" title="4折抢购!十二生肖925银女戒指,时尚开口女戒"><?php echo e($v->good_name); ?></a></div>
                                        <div class="s-new_price-box">
                                            <span class="s-new_price"><em class="s-new_price-sign">¥</em><em class="s-value"><?php echo e($v->new_price); ?></em></span>
                                            <span class="s-history-new_price"><em class="s-new_price-sign">¥</em><em class="s-value"><?php echo e($v->old_price); ?></em></span>
                                        </div>
                                        <div class="s-extra-box">
                                            <span class="s-comment">好评: 99.93%</span>
                                            <span class="s-sales">月销: <?php echo e($v->month_sale); ?></span>
                                        </div>
                                    </div>
                                    <div class="s-tp">
                                        <a href="<?php echo e(url('Goods/seach')); ?>?id=<?php echo e($v->cate_id); ?>">
                                            <span class="ui-btn-loading-before">找相似</span>
                                        </a>
                                        <i class="am-icon-trash"></i>
                                        <p>
                                            <a href="javascript:void(0);" class="c-nodo J_delFav_btn">取消收藏</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <script>
                        $('.goods-All').click(function(){
                            layui.use("layer",function(){
                                layer.confirm('是否要删除所有收藏？', {
                                    btn: ['是的','取消'] //按钮
                                }, function(){
                                    var _token = "<?php echo e(csrf_token()); ?>";
                                    $.post("<?php echo e(url('Goods/collectionAction')); ?>",{_token:_token},function(status){
                                        if (status) {
                                            $('.s-content').remove();
                                            layer.msg('删除成功!', {icon: 1});
                                        }
                                    },'json')
                                })
                            })
                        })
                    </script>
                </div>
            </div>
        </div>
        <!--底部-->
        <?php echo $__env->make('Public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <?php echo $__env->make('Public.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

</body>

</html>
