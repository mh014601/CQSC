<div class="nav white">
    <div class="logo"><img src="<?php echo e(asset('images/logo.png')); ?>" /></div>
    <div class="logoBig">
        <li><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/logobig.png')); ?>" /></a></li>
    </div>

    <div class="search-bar pr">
        <a name="index_none_header_sysc" href="#"></a>
        <form action="<?php echo e(url('Goods/seach')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input id="searchInput" name="keywords" type="text" placeholder="搜索" autocomplete="off">
            <input id="ai-topsearch" class="submit am-btn" value="搜索" index="1" type="submit">
        </form>
    </div>
</div>
