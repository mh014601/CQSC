<div class="footer ">
    <div class="footer-hd ">
        <p>
            <a href="<?php echo e(url('/')); ?> ">传奇科技</a>
            <b>|</b>
            <a href="<?php echo e(url('/')); ?> ">商城首页</a>
            <b>|</b>
            <a href="https://www.alipay.com/">支付宝</a>
            <b>|</b>
            <a href="<?php echo e(url('/')); ?> ">物流</a>
        </p>
    </div>
    <div class="footer-bd ">
        <p>
            <a href="<?php echo e(url('/')); ?> ">关于传奇</a>
            <a href="<?php echo e(url('/')); ?> ">合作伙伴</a>
            <a href="<?php echo e(url('/')); ?> ">联系我们</a>
            <a href="<?php echo e(url('/')); ?> ">网站地图</a>
            <em>© 2019-2029 chuanqi.com 仅供测试,不进行任何商业用途或盈利</em>
        </p>
    </div>
</div>