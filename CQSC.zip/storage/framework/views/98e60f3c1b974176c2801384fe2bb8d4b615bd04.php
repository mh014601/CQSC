<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=0">

    <title>我的足迹</title>

    <link href="<?php echo e(asset('AmazeUI-2.4.2/assets/css/admin.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('AmazeUI-2.4.2/assets/css/amazeui.css')); ?>" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <link href="<?php echo e(asset('css/personal.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/footstyle.css')); ?>" rel="stylesheet" type="text/css">
    <script src="<?php echo e(asset('layui/layui/layui.js')); ?>"></script>
</head>

<body>
<!--头 -->
<header>
    <article>
        <div class="mt-logo">
            <!--顶部导航条 -->
        <?php echo $__env->make('Public.header1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!--悬浮搜索框-->

            <?php echo $__env->make('Public.seach1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="clear"></div>
        </div>
        </div>
    </article>
</header>
<div class="nav-table">
    <?php echo $__env->make('Public.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<b class="line"></b>
<div class="center">
    <div class="col-main">
        <div class="main-wrap">

            <div class="user-foot">
                <!--标题 -->
                <div class="am-cf am-padding">
                    <div class="am-fl am-cf"><strong class="am-text-danger am-text-lg">我的足迹</strong> / <small>Browser&nbsp;History</small></div>
                </div>
                <hr/>

                <!--足迹列表 -->
                
                <div>
                    <div class="goods-date" data-date="2015-12-21">
                        <span><i class="month-lite"><?php echo e($today); ?></i><i class="date-desc">今天</i></span>
                        <del class="am-icon-trash goods-All" ad="today"></del>
                        <s class="line"></s>
                    </div>

                    <p id="tishi_today" style="color: red"></p>

                    <div class="goods-date" id="goods_today" >
                        <?php if(!$todayR): ?>
                            <p id="today2" style="color: red">今天的数据为空</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $todayRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="goods" id="goods_<?php echo e($rows->id); ?>">
                                    <div class="goods-box first-box">
                                        <div class="goods-pic">
                                            <div class="goods-pic-box">
                                                <a class="goods-pic-link" href="<?php echo e(url('Home/Goods/goodsInfo')); ?>?id=<?php echo e($rows->id); ?>" title="<?php echo e($rows->good_name); ?>">
                                                    <img src='<?php echo e(asset("upload/$rows->pic")); ?>' class="goods-img"></a>
                                            </div>
                                            <a class="goods-delete delete_goods" href="javascript:void(0);" ad="<?php echo e($rows->id); ?>" ><i class="am-icon-trash"></i></a>
                                        </div>

                                        <div class="goods-attr">
                                            <div class="good-title">
                                                <a class="title" href="<?php echo e(url('Home/Goods/goodsInfo')); ?>?id=<?php echo e($rows->id); ?>" ><?php echo e($rows->good_name); ?></a>
                                            </div>
                                            <div class="goods-price">
										<span class="g_price">
                                        <span>¥</span><strong><?php echo e($rows->new_price); ?></strong>
										</span>
                                                <span class="g_price g_price-original">
                                        <span>¥</span><strong><?php echo e($rows->old_price); ?></strong>
										</span>
                                            </div>
                                            <div class="clear"></div>
                                            <div class="goods-num">
                                                <div class="match-recom">
                                                    <a href="<?php echo e(url('Goods/seach')); ?>?id=<?php echo e($rows->cate_id); ?>" class="match-recom-item" cate="<?php echo e($rows->cate_id); ?>">找相似</a>
                                                    <a href="<?php echo e(url('Goods/seach')); ?>?id=<?php echo e($rows->cate_id); ?>" class="match-recom-item" >找搭配</a>
                                                    <i><em></em><span></span></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>


                </div>

                <div class="clear"></div>
                
                <div>
                    <div class="goods-date" data-date="2015-12-17">
                        <span><i class="month-lite"></i><i class="day-lite"></i>	<i class="date-desc">一周的足迹</i></span>
                        <a href="javascript:void(0)">
                            <del class="am-icon-trash goods-All" ad="week"></del>
                        </a>
                        <s class="line"></s>
                    </div>
                    <p id="tishi_week" style="color: red"></p>
                    <div class="goods-date" id="goods_week" >
                        <?php if(!$weekR): ?>
                            <p id="week2" style="color: red">数据为空.........</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $weekRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="goods" id="goods_<?php echo e($rows->id); ?>" >
                                    <div class="goods-box first-box">
                                        <div class="goods-pic">
                                            <div class="goods-pic-box">
                                                <a class="goods-pic-link" href="<?php echo e(url('Goods/goodsInfo')); ?>?id=<?php echo e($rows->id); ?>" title="<?php echo e($rows->good_name); ?>">
                                                    <img src='<?php echo e(asset("upload/$rows->pic")); ?>' class="goods-img"></a>
                                            </div>
                                            <a class="goods-delete delete_goods" href="javascript:void(0);" ad="<?php echo e($rows->id); ?>"><i class="am-icon-trash"></i></a>
                                        </div>

                                        <div class="goods-attr">
                                            <div class="good-title">
                                                <a class="title" href="<?php echo e(url('Goods/goodsInfo')); ?>?id=<?php echo e($rows->id); ?>" ><?php echo e($rows->good_name); ?></a>
                                            </div>
                                            <div class="goods-price">
										<span class="g_price">
                                        <span>¥</span><strong><?php echo e($rows->new_price); ?></strong>
										</span>
                                                <span class="g_price g_price-original">
                                        <span>¥</span><strong><?php echo e($rows->old_price); ?></strong>
										</span>
                                            </div>
                                            <div class="clear"></div>
                                            <div class="goods-num">
                                                <div class="match-recom">
                                                    <a href="<?php echo e(url('Goods/seach')); ?>?id=<?php echo e($rows->cate_id); ?>" class="match-recom-item" cate="<?php echo e($rows->cate_id); ?>">找相似</a>
                                                    <a href="<?php echo e(url('Goods/seach')); ?>?id=<?php echo e($rows->cate_id); ?>" class="match-recom-item" >找搭配</a>
                                                    <i><em></em><span></span></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>

        <!--底部-->
        <?php echo $__env->make('Public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <?php echo $__env->make('Public.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

</body>
<script>
    
    $('.goods-All').click(function(){
        var ad = $(this).attr('ad');
        var today = "toady";
        layui.use('layer', function () {
            layer.confirm('你确定删除浏览记录？', {
                btn: ['是的','取消'] //按钮
            }, function(){
                var _token = "<?php echo e(csrf_token()); ?>";
                $.post("<?php echo e(url('Goods/footAction')); ?>",{_token:_token,ad:ad},function(status){
                    if (status){

                        // alert("goods_"+ad);
                        $('#goods_'+ad).remove();

                        $("#tishi_"+ad).text("没有历史记录! 快快选购自己喜欢的商品吧!");

                        layer.msg('删除成功!', {icon: 1});
                        //     // $('#goods_'+ad).text("没有历史记录! 快快选购自己喜欢的商品吧!");
                        // }else{
                        //     $('#goods_'+ad).remove();
                        //     layer.msg('删除成功!', {icon: 1});
                        //     //
                        // }
                    }
                },'json');
            })
        })
    })
</script>
<script>
    
    $('.delete_goods').click(function(){
        var product_id = $(this).attr('ad');
        layui.use("layer",function(){
            layer.confirm('你确定要删除吗？', {
                btn: ['是的','取消'] //按钮
            }, function(){
                // alert(product_id);
                var _token = "<?php echo e(csrf_token()); ?>";
                $.post("<?php echo e(url('Goods/footAction')); ?>",{_token:_token,product_id:product_id},function(status){
                    if (status){
                        $("#goods_"+product_id).remove();
                        layer.msg('删除成功!', {icon: 1});
                    }
                },'json')
            })
        })
    })

</script>
</html>
