<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>底部</title>
    <link href="<?php echo e(asset('Admin/css/style.css')); ?>" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="footer">
    <span>仅供学习交流，请勿用于任何商业用途</span>
    <i>版权所有 2014 www.yhshop.com</i>
</div>
</body>
</html>

