<div class="long-title"><span class="all-goods">全部分类</span></div>
<div class="nav-cont">
    <ul>
        <li class="index"><a href="<?php echo e(url('/')); ?>">首页</a></li>
        <li class="qc"><a href="<?php echo e(url('/')); ?>">闪购</a></li>
        <li class="qc"><a href="<?php echo e(url('/')); ?>">限时抢</a></li>
        <li class="qc"><a href="<?php echo e(url('/')); ?>">团购</a></li>
        <li class="qc last"><a href="<?php echo e(url('/')); ?>">大包装</a></li>
    </ul>
    <a href="<?php echo e(url('Home/Infor/information')); ?>"> <div class="nav-extra">
            <i class="am-icon-user-secret am-icon-md nav-user"></i><b></b>我的福利
            <i class="am-icon-angle-right" style="padding-left: 10px;"></i>
        </div></a>
</div>