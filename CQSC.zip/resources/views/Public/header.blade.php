<div class="long-title"><span class="all-goods">全部分类</span></div>
<div class="nav-cont">
    <ul>
        <li class="index"><a href="{{url('/')}}">首页</a></li>
        <li class="qc"><a href="{{url('/')}}">闪购</a></li>
        <li class="qc"><a href="{{url('/')}}">限时抢</a></li>
        <li class="qc"><a href="{{url('/')}}">团购</a></li>
        <li class="qc last"><a href="{{url('/')}}">大包装</a></li>
    </ul>
    <a href="{{url('Home/Infor/information')}}"> <div class="nav-extra">
            <i class="am-icon-user-secret am-icon-md nav-user"></i><b></b>我的福利
            <i class="am-icon-angle-right" style="padding-left: 10px;"></i>
        </div></a>
</div>